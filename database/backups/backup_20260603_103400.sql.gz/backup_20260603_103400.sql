--
-- PostgreSQL database dump
--

\restrict XchIg4hLueG6udYxU91sXPPqYGySFHwtSUUxVneXyKoH9CpdrLbA3NhCoamTddW

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: chatflow_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO chatflow_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_usage; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.api_usage (
    id integer NOT NULL,
    user_id integer,
    phone_number_id integer,
    endpoint character varying(100) NOT NULL,
    method character varying(10) NOT NULL,
    status_code integer NOT NULL,
    response_time integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.api_usage OWNER TO chatflow_user;

--
-- Name: api_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.api_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_usage_id_seq OWNER TO chatflow_user;

--
-- Name: api_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.api_usage_id_seq OWNED BY public.api_usage.id;


--
-- Name: auto_reply_configs; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.auto_reply_configs (
    id integer NOT NULL,
    user_id integer,
    name character varying(100) NOT NULL,
    trigger_keywords text[] NOT NULL,
    welcome_message text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    phone_numbers integer[] DEFAULT '{}'::integer[]
);


ALTER TABLE public.auto_reply_configs OWNER TO chatflow_user;

--
-- Name: auto_reply_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.auto_reply_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auto_reply_configs_id_seq OWNER TO chatflow_user;

--
-- Name: auto_reply_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.auto_reply_configs_id_seq OWNED BY public.auto_reply_configs.id;


--
-- Name: auto_reply_logs; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.auto_reply_logs (
    id integer NOT NULL,
    phone_number character varying(20) NOT NULL,
    incoming_message text NOT NULL,
    outgoing_message text NOT NULL,
    menu_path character varying(100),
    response_time integer,
    session_id integer,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.auto_reply_logs OWNER TO chatflow_user;

--
-- Name: auto_reply_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.auto_reply_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auto_reply_logs_id_seq OWNER TO chatflow_user;

--
-- Name: auto_reply_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.auto_reply_logs_id_seq OWNED BY public.auto_reply_logs.id;


--
-- Name: auto_reply_menus; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.auto_reply_menus (
    id integer NOT NULL,
    config_id integer,
    menu_key character varying(10) NOT NULL,
    menu_text text NOT NULL,
    response_text text NOT NULL,
    parent_menu_id integer,
    is_active boolean DEFAULT true,
    order_index integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.auto_reply_menus OWNER TO chatflow_user;

--
-- Name: auto_reply_menus_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.auto_reply_menus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auto_reply_menus_id_seq OWNER TO chatflow_user;

--
-- Name: auto_reply_menus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.auto_reply_menus_id_seq OWNED BY public.auto_reply_menus.id;


--
-- Name: auto_reply_sessions; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.auto_reply_sessions (
    id integer NOT NULL,
    phone_number character varying(20) NOT NULL,
    config_id integer,
    current_menu_id integer,
    session_data jsonb DEFAULT '{}'::jsonb,
    last_interaction timestamp without time zone DEFAULT now(),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    phone_number_id integer
);


ALTER TABLE public.auto_reply_sessions OWNER TO chatflow_user;

--
-- Name: auto_reply_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.auto_reply_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auto_reply_sessions_id_seq OWNER TO chatflow_user;

--
-- Name: auto_reply_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.auto_reply_sessions_id_seq OWNED BY public.auto_reply_sessions.id;


--
-- Name: broadcast_messages; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.broadcast_messages (
    id integer NOT NULL,
    broadcast_id integer,
    contact_id integer,
    phone character varying(20) NOT NULL,
    message text NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    sent_at timestamp without time zone,
    error_message text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.broadcast_messages OWNER TO chatflow_user;

--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.broadcast_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.broadcast_messages_id_seq OWNER TO chatflow_user;

--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.broadcast_messages_id_seq OWNED BY public.broadcast_messages.id;


--
-- Name: broadcast_progress; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.broadcast_progress (
    id integer NOT NULL,
    broadcast_id integer,
    total_contacts integer DEFAULT 0,
    processed_contacts integer DEFAULT 0,
    sent_messages integer DEFAULT 0,
    failed_messages integer DEFAULT 0,
    progress_percentage numeric(5,2) DEFAULT 0,
    estimated_completion timestamp without time zone,
    last_updated timestamp without time zone DEFAULT now()
);


ALTER TABLE public.broadcast_progress OWNER TO chatflow_user;

--
-- Name: broadcast_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.broadcast_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.broadcast_progress_id_seq OWNER TO chatflow_user;

--
-- Name: broadcast_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.broadcast_progress_id_seq OWNED BY public.broadcast_progress.id;


--
-- Name: broadcast_recipients; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.broadcast_recipients (
    id integer NOT NULL,
    broadcast_id integer,
    contact_id integer,
    status character varying(20) DEFAULT 'pending'::character varying,
    sent_at timestamp without time zone,
    failed_at timestamp without time zone,
    message_id text,
    error_message text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.broadcast_recipients OWNER TO chatflow_user;

--
-- Name: broadcast_recipients_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.broadcast_recipients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.broadcast_recipients_id_seq OWNER TO chatflow_user;

--
-- Name: broadcast_recipients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.broadcast_recipients_id_seq OWNED BY public.broadcast_recipients.id;


--
-- Name: broadcast_templates; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.broadcast_templates (
    id integer NOT NULL,
    user_id integer,
    name character varying(255) NOT NULL,
    description text,
    message text NOT NULL,
    variables jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.broadcast_templates OWNER TO chatflow_user;

--
-- Name: broadcast_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.broadcast_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.broadcast_templates_id_seq OWNER TO chatflow_user;

--
-- Name: broadcast_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.broadcast_templates_id_seq OWNED BY public.broadcast_templates.id;


--
-- Name: broadcasts; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.broadcasts (
    id integer NOT NULL,
    user_id integer,
    name character varying(255) NOT NULL,
    description text,
    message text NOT NULL,
    template_id integer,
    contact_filter jsonb,
    status character varying(50) DEFAULT 'draft'::character varying,
    total_contacts integer DEFAULT 0,
    sent_count integer DEFAULT 0,
    failed_count integer DEFAULT 0,
    scheduled_at timestamp without time zone,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.broadcasts OWNER TO chatflow_user;

--
-- Name: broadcasts_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.broadcasts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.broadcasts_id_seq OWNER TO chatflow_user;

--
-- Name: broadcasts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.broadcasts_id_seq OWNED BY public.broadcasts.id;


--
-- Name: contact_categories; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.contact_categories (
    id integer NOT NULL,
    user_id integer,
    name character varying(100) NOT NULL,
    description text,
    color character varying(7) DEFAULT '#1976d2'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.contact_categories OWNER TO chatflow_user;

--
-- Name: contact_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.contact_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_categories_id_seq OWNER TO chatflow_user;

--
-- Name: contact_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.contact_categories_id_seq OWNED BY public.contact_categories.id;


--
-- Name: contact_category_relations; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.contact_category_relations (
    id integer NOT NULL,
    contact_id integer,
    category_id integer,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.contact_category_relations OWNER TO chatflow_user;

--
-- Name: contact_category_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.contact_category_relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_category_relations_id_seq OWNER TO chatflow_user;

--
-- Name: contact_category_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.contact_category_relations_id_seq OWNED BY public.contact_category_relations.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.contacts (
    id integer NOT NULL,
    user_id integer,
    name character varying(255) NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(255),
    company character varying(255),
    address text,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    categories text[] DEFAULT '{}'::text[]
);


ALTER TABLE public.contacts OWNER TO chatflow_user;

--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contacts_id_seq OWNER TO chatflow_user;

--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: incoming_messages; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.incoming_messages (
    id integer NOT NULL,
    message_id character varying(100) NOT NULL,
    phone_id integer,
    device_id character varying(100),
    sender_phone character varying(20) NOT NULL,
    sender_name character varying(100),
    message_type character varying(20) DEFAULT 'text'::character varying,
    message_content text,
    is_group boolean DEFAULT false,
    group_id character varying(100),
    raw_payload jsonb,
    received_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    is_revoked boolean DEFAULT false
);


ALTER TABLE public.incoming_messages OWNER TO chatflow_user;

--
-- Name: incoming_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.incoming_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.incoming_messages_id_seq OWNER TO chatflow_user;

--
-- Name: incoming_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.incoming_messages_id_seq OWNED BY public.incoming_messages.id;


--
-- Name: message_templates; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.message_templates (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(100) NOT NULL,
    content text NOT NULL,
    category character varying(50) DEFAULT 'general'::character varying,
    variables jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.message_templates OWNER TO chatflow_user;

--
-- Name: message_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.message_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_templates_id_seq OWNER TO chatflow_user;

--
-- Name: message_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.message_templates_id_seq OWNED BY public.message_templates.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    phone_number_id integer,
    message_id character varying(100) NOT NULL,
    from_number character varying(20) NOT NULL,
    to_number character varying(20) NOT NULL,
    message_type character varying(20) NOT NULL,
    content text,
    media_url character varying(500),
    media_type character varying(50),
    status character varying(20) DEFAULT 'pending'::character varying,
    webhook_sent boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.messages OWNER TO chatflow_user;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO chatflow_user;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: phone_numbers; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.phone_numbers (
    id integer NOT NULL,
    user_id integer,
    phone_number character varying(20) NOT NULL,
    device_name character varying(100),
    token character varying(255) NOT NULL,
    webhook_url character varying(500),
    webhook_secret character varying(255),
    is_connected boolean DEFAULT false,
    last_seen timestamp with time zone,
    qr_code text,
    session_data jsonb,
    auto_reply text,
    auto_mark_read boolean DEFAULT false,
    auto_download_media boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    evolution_instance character varying(255)
);


ALTER TABLE public.phone_numbers OWNER TO chatflow_user;

--
-- Name: phone_numbers_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.phone_numbers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.phone_numbers_id_seq OWNER TO chatflow_user;

--
-- Name: phone_numbers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.phone_numbers_id_seq OWNED BY public.phone_numbers.id;


--
-- Name: rate_limits; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.rate_limits (
    id integer NOT NULL,
    user_id integer,
    window_start timestamp with time zone NOT NULL,
    request_count integer DEFAULT 0,
    limit_per_hour integer DEFAULT 1000,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.rate_limits OWNER TO chatflow_user;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.rate_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rate_limits_id_seq OWNER TO chatflow_user;

--
-- Name: rate_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.rate_limits_id_seq OWNED BY public.rate_limits.id;


--
-- Name: scheduled_messages; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.scheduled_messages (
    id integer NOT NULL,
    user_id integer,
    phone_id integer,
    recipient character varying(50) NOT NULL,
    message text NOT NULL,
    scheduled_at timestamp without time zone NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    sent_at timestamp without time zone,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.scheduled_messages OWNER TO chatflow_user;

--
-- Name: scheduled_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.scheduled_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduled_messages_id_seq OWNER TO chatflow_user;

--
-- Name: scheduled_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.scheduled_messages_id_seq OWNED BY public.scheduled_messages.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    api_key character varying(255) NOT NULL,
    jwt_secret character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO chatflow_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO chatflow_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: chatflow_user
--

CREATE TABLE public.webhook_events (
    id integer NOT NULL,
    phone_number_id integer,
    event_type character varying(50) NOT NULL,
    payload jsonb NOT NULL,
    retry_count integer DEFAULT 0,
    status character varying(20) DEFAULT 'pending'::character varying,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.webhook_events OWNER TO chatflow_user;

--
-- Name: webhook_events_id_seq; Type: SEQUENCE; Schema: public; Owner: chatflow_user
--

CREATE SEQUENCE public.webhook_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.webhook_events_id_seq OWNER TO chatflow_user;

--
-- Name: webhook_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chatflow_user
--

ALTER SEQUENCE public.webhook_events_id_seq OWNED BY public.webhook_events.id;


--
-- Name: api_usage id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.api_usage ALTER COLUMN id SET DEFAULT nextval('public.api_usage_id_seq'::regclass);


--
-- Name: auto_reply_configs id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_configs ALTER COLUMN id SET DEFAULT nextval('public.auto_reply_configs_id_seq'::regclass);


--
-- Name: auto_reply_logs id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_logs ALTER COLUMN id SET DEFAULT nextval('public.auto_reply_logs_id_seq'::regclass);


--
-- Name: auto_reply_menus id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_menus ALTER COLUMN id SET DEFAULT nextval('public.auto_reply_menus_id_seq'::regclass);


--
-- Name: auto_reply_sessions id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_sessions ALTER COLUMN id SET DEFAULT nextval('public.auto_reply_sessions_id_seq'::regclass);


--
-- Name: broadcast_messages id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_messages ALTER COLUMN id SET DEFAULT nextval('public.broadcast_messages_id_seq'::regclass);


--
-- Name: broadcast_progress id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_progress ALTER COLUMN id SET DEFAULT nextval('public.broadcast_progress_id_seq'::regclass);


--
-- Name: broadcast_recipients id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_recipients ALTER COLUMN id SET DEFAULT nextval('public.broadcast_recipients_id_seq'::regclass);


--
-- Name: broadcast_templates id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_templates ALTER COLUMN id SET DEFAULT nextval('public.broadcast_templates_id_seq'::regclass);


--
-- Name: broadcasts id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcasts ALTER COLUMN id SET DEFAULT nextval('public.broadcasts_id_seq'::regclass);


--
-- Name: contact_categories id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_categories ALTER COLUMN id SET DEFAULT nextval('public.contact_categories_id_seq'::regclass);


--
-- Name: contact_category_relations id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_category_relations ALTER COLUMN id SET DEFAULT nextval('public.contact_category_relations_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: incoming_messages id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.incoming_messages ALTER COLUMN id SET DEFAULT nextval('public.incoming_messages_id_seq'::regclass);


--
-- Name: message_templates id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.message_templates ALTER COLUMN id SET DEFAULT nextval('public.message_templates_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: phone_numbers id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.phone_numbers ALTER COLUMN id SET DEFAULT nextval('public.phone_numbers_id_seq'::regclass);


--
-- Name: rate_limits id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.rate_limits ALTER COLUMN id SET DEFAULT nextval('public.rate_limits_id_seq'::regclass);


--
-- Name: scheduled_messages id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.scheduled_messages ALTER COLUMN id SET DEFAULT nextval('public.scheduled_messages_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: webhook_events id; Type: DEFAULT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.webhook_events ALTER COLUMN id SET DEFAULT nextval('public.webhook_events_id_seq'::regclass);


--
-- Data for Name: api_usage; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.api_usage (id, user_id, phone_number_id, endpoint, method, status_code, response_time, created_at) FROM stdin;
\.


--
-- Data for Name: auto_reply_configs; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.auto_reply_configs (id, user_id, name, trigger_keywords, welcome_message, is_active, created_at, updated_at, phone_numbers) FROM stdin;
1	1	HR Helpdesk	{halo,help,bantuan,info}	Halo, ada yang bisa saya bantu?\n====================\nInfo lainnya, silakan KETIK angka:\n1.👉🏻 Data Karyawan\n2.👉🏻 Data dan Form Cuti\n3.👉🏻 Data dan Form Lembur\n4.👉🏻 Password Akun\n5.👉🏻 Lowongan Kerja\n====================	t	2026-02-10 12:35:33.715917	2026-02-10 12:35:33.715917	{}
2	1	HR Helpdesk - Specific Phone	{halo,help,bantuan,info}	Ass.wr.wb, ada yang bisa saya bantu? (Test Auto Reply)	t	2026-02-10 12:57:32.329541	2026-02-10 13:05:23.793418	{6}
3	1	BIsmillah	{halo}	halo juga	t	2026-02-11 02:56:10.150697	2026-02-11 04:58:21.720242	{8}
\.


--
-- Data for Name: auto_reply_logs; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.auto_reply_logs (id, phone_number, incoming_message, outgoing_message, menu_path, response_time, session_id, created_at) FROM stdin;
34	+62818223304	halo	halo juga	welcome	38	7	2026-02-11 04:31:58.941297
35	+62818223304	halo	Menu tidak ditemukan. Silakan pilih nomor yang tersedia atau ketik "0" untuk kembali ke menu utama.	error	19	7	2026-02-11 04:32:25.735411
36	+62818223304	halo	Menu tidak ditemukan. Silakan pilih nomor yang tersedia atau ketik "0" untuk kembali ke menu utama.	error	40	7	2026-02-11 04:33:30.109632
37	+62818223304	halo	Menu tidak ditemukan. Silakan pilih nomor yang tersedia atau ketik "0" untuk kembali ke menu utama.	error	10	7	2026-02-11 04:33:50.333442
38	+62818223304	halo	Menu tidak ditemukan. Silakan pilih nomor yang tersedia atau ketik "0" untuk kembali ke menu utama.	error	7	7	2026-02-11 04:34:04.901726
39	+62818223304	halo	Menu tidak ditemukan. Silakan pilih nomor yang tersedia atau ketik "0" untuk kembali ke menu utama.	error	13	7	2026-02-11 04:35:32.892108
40	+62818223304	halo	Menu tidak ditemukan. Silakan pilih nomor yang tersedia atau ketik "0" untuk kembali ke menu utama.	error	19	7	2026-02-11 04:37:36.714399
41	+62818223304	halo	halo juga	welcome	17	7	2026-02-11 04:39:34.422219
42	+62818223304	halo	halo juga	welcome	12	7	2026-02-11 04:40:17.342161
43	+62818223304	halo	halo juga	welcome	8	7	2026-02-11 04:43:16.523137
44	+62818223304	halo	halo juga	welcome	8	7	2026-02-11 04:59:28.280799
45	+62818223304	halo	halo juga	welcome	17	7	2026-02-11 05:02:18.17545
46	+62818223304	halo	halo juga\n\nSilakan pilih:\n1. Roti Canai\n2. Roti Prata\n\nKetik "0" untuk kembali ke menu utama	welcome	30	7	2026-02-11 05:03:49.298281
47	+62818223304	halo	halo juga\n\nSilakan pilih:\n1. Roti Canai\n2. Roti Prata\n\nKetik "0" untuk kembali ke menu utama	welcome	18	7	2026-02-11 05:04:14.524543
48	+62818223304	halo	halo juga\n\nSilakan pilih:\n1. Roti Canai\n2. Roti Prata\n\nKetik "0" untuk kembali ke menu utama	welcome	174	7	2026-02-11 05:16:14.204976
49	+62818223304	halo	halo juga\n\nSilakan pilih:\n1. Roti Canai\n2. Roti Prata\n\nKetik "0" untuk kembali ke menu utama	welcome	93	7	2026-02-11 05:17:06.273833
\.


--
-- Data for Name: auto_reply_menus; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.auto_reply_menus (id, config_id, menu_key, menu_text, response_text, parent_menu_id, is_active, order_index, created_at) FROM stdin;
1	1	1	👉🏻 Data Karyawan	Untuk data karyawan, silakan akses: https://hr.company.com/employees\n\nKetik "0" untuk kembali ke menu utama	\N	t	0	2026-02-10 12:35:33.722994
2	1	2	👉🏻 Data dan Form Cuti	Form cuti tersedia di: https://hr.company.com/cuti\n\nKetik "0" untuk kembali ke menu utama	\N	t	0	2026-02-10 12:35:33.72752
3	1	3	👉🏻 Data dan Form Lembur	Form lembur tersedia di: https://hr.company.com/lembur\n\nKetik "0" untuk kembali ke menu utama	\N	t	0	2026-02-10 12:35:33.730824
4	1	4	👉🏻 Password Akun	Untuk reset password, hubungi IT Helpdesk di ext. 1234\n\nKetik "0" untuk kembali ke menu utama	\N	t	0	2026-02-10 12:35:33.733146
5	1	5	👉🏻 Lowongan Kerja	Lowongan tersedia di: https://careers.company.com\n\nKetik "0" untuk kembali ke menu utama	\N	t	0	2026-02-10 12:35:33.735416
11	3	1	Roti Canai	Terima kasih 	\N	t	0	2026-02-11 04:58:21.731066
12	3	2	Roti Prata	Terima kasih sudah memesan roti prata	\N	t	1	2026-02-11 04:58:21.734541
\.


--
-- Data for Name: auto_reply_sessions; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.auto_reply_sessions (id, phone_number, config_id, current_menu_id, session_data, last_interaction, is_active, created_at, phone_number_id) FROM stdin;
7	+62818223304	3	\N	{}	2026-02-11 05:17:06.283704	t	2026-02-11 04:31:58.924868	8
\.


--
-- Data for Name: broadcast_messages; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.broadcast_messages (id, broadcast_id, contact_id, phone, message, status, sent_at, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: broadcast_progress; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.broadcast_progress (id, broadcast_id, total_contacts, processed_contacts, sent_messages, failed_messages, progress_percentage, estimated_completion, last_updated) FROM stdin;
\.


--
-- Data for Name: broadcast_recipients; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.broadcast_recipients (id, broadcast_id, contact_id, status, sent_at, failed_at, message_id, error_message, created_at, updated_at) FROM stdin;
8	14	24	failed	\N	2026-02-10 04:08:23.349278	\N	Request failed with status code 404	2026-02-10 04:08:23.349278	2026-02-10 04:08:23.349278
9	15	24	failed	\N	2026-02-10 04:13:08.575181	\N	Request failed with status code 404	2026-02-10 04:13:08.575181	2026-02-10 04:13:08.575181
10	16	24	failed	\N	2026-02-10 04:18:06.524519	\N	Request failed with status code 404	2026-02-10 04:18:06.524519	2026-02-10 04:18:06.524519
11	17	24	failed	\N	2026-02-10 04:21:17.150216	\N	Request failed with status code 404	2026-02-10 04:21:17.150216	2026-02-10 04:21:17.150216
12	18	24	failed	\N	2026-02-10 07:11:45.841607	\N	Request failed with status code 404	2026-02-10 07:11:45.841607	2026-02-10 07:11:45.841607
13	19	24	sent	2026-02-10 08:01:51.671354	\N	\N	\N	2026-02-10 08:01:51.671354	2026-02-10 08:01:51.671354
14	20	24	sent	2026-02-10 08:09:54.658266	\N	\N	\N	2026-02-10 08:09:54.658266	2026-02-10 08:09:54.658266
15	21	24	sent	2026-02-10 08:14:14.484018	\N	\N	\N	2026-02-10 08:14:14.484018	2026-02-10 08:14:14.484018
16	22	24	sent	2026-02-10 08:16:37.886373	\N	\N	\N	2026-02-10 08:16:37.886373	2026-02-10 08:16:37.886373
17	23	24	sent	2026-02-10 09:55:59.468144	\N	\N	\N	2026-02-10 09:55:59.468144	2026-02-10 09:55:59.468144
18	28	24	sent	2026-02-10 10:30:43.100803	\N	\N	\N	2026-02-10 10:30:43.100803	2026-02-10 10:30:43.100803
19	28	27	sent	2026-02-10 10:30:45.862852	\N	\N	\N	2026-02-10 10:30:45.862852	2026-02-10 10:30:45.862852
20	27	24	sent	2026-02-10 10:37:55.646897	\N	\N	\N	2026-02-10 10:37:55.646897	2026-02-10 10:37:55.646897
21	27	27	sent	2026-02-10 10:37:58.144171	\N	\N	\N	2026-02-10 10:37:58.144171	2026-02-10 10:37:58.144171
22	25	24	sent	2026-02-10 10:38:28.905738	\N	\N	\N	2026-02-10 10:38:28.905738	2026-02-10 10:38:28.905738
23	25	27	sent	2026-02-10 10:38:31.432278	\N	\N	\N	2026-02-10 10:38:31.432278	2026-02-10 10:38:31.432278
24	29	24	sent	2026-02-10 10:41:11.106892	\N	\N	\N	2026-02-10 10:41:11.106892	2026-02-10 10:41:11.106892
25	29	27	sent	2026-02-10 10:41:13.698109	\N	\N	\N	2026-02-10 10:41:13.698109	2026-02-10 10:41:13.698109
26	30	24	sent	2026-02-10 11:03:21.733957	\N	\N	\N	2026-02-10 11:03:21.733957	2026-02-10 11:03:21.733957
27	30	27	sent	2026-02-10 11:03:24.231668	\N	\N	\N	2026-02-10 11:03:24.231668	2026-02-10 11:03:24.231668
28	31	24	sent	2026-02-10 11:28:47.741115	\N	\N	\N	2026-02-10 11:28:47.741115	2026-02-10 11:28:47.741115
29	31	27	sent	2026-02-10 11:28:49.680011	\N	\N	\N	2026-02-10 11:28:49.680011	2026-02-10 11:28:49.680011
30	32	24	sent	2026-02-10 14:28:52.391972	\N	\N	\N	2026-02-10 14:28:52.391972	2026-02-10 14:28:52.391972
31	32	27	sent	2026-02-10 14:28:54.310297	\N	\N	\N	2026-02-10 14:28:54.310297	2026-02-10 14:28:54.310297
\.


--
-- Data for Name: broadcast_templates; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.broadcast_templates (id, user_id, name, description, message, variables, created_at, updated_at) FROM stdin;
1	1	Welcome Template	Welcome message template	Hello {name}, welcome to our service!	{"name": "text"}	2026-02-09 10:21:45.523134	2026-02-09 10:21:45.523134
\.


--
-- Data for Name: broadcasts; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.broadcasts (id, user_id, name, description, message, template_id, contact_filter, status, total_contacts, sent_count, failed_count, scheduled_at, started_at, completed_at, created_at, updated_at) FROM stdin;
18	1	Test dengan Connected Device	Test broadcast dengan device yang sudah connected	Hello {name}, test dengan device yang sudah connected!	\N	{"search": "", "categories": ["kawan2"]}	completed_with_errors	1	0	1	\N	2026-02-10 07:11:45.820186	2026-02-10 07:11:45.846106	2026-02-10 07:11:39.473267	2026-02-10 07:11:45.829819
19	1	BIsmillah	desc	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	completed	1	1	0	\N	2026-02-10 08:01:48.628075	2026-02-10 08:01:51.678768	2026-02-10 08:01:45.734231	2026-02-10 08:01:48.643284
20	1	BISMILLAH	BIsmillah	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	completed	1	1	0	\N	2026-02-10 08:09:52.230837	2026-02-10 08:09:54.665769	2026-02-10 08:09:48.602942	2026-02-10 08:09:52.239834
21	1	bismillah	cuba lagi	bismillah	\N	{"search": "", "categories": ["kawan2"]}	completed	1	1	0	\N	2026-02-10 08:14:12.466392	2026-02-10 08:14:14.494048	2026-02-10 08:14:09.102251	2026-02-10 08:14:12.49572
22	1	Bismillah	desc	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	completed	1	1	0	\N	2026-02-10 08:16:35.795835	2026-02-10 08:16:37.894944	2026-02-10 08:16:16.006588	2026-02-10 08:16:35.81182
23	1	BIsmillah	desc	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	completed	1	1	0	\N	2026-02-10 09:55:56.008351	2026-02-10 09:55:59.471803	2026-02-10 09:55:51.849187	2026-02-10 09:55:56.053453
24	1	Template	desc	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	draft	1	0	0	\N	\N	\N	2026-02-10 10:01:31.414595	2026-02-10 10:01:31.414595
28	1	desc	saw	asdasd	\N	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 10:30:40.188161	2026-02-10 10:30:45.867796	2026-02-10 10:30:36.716403	2026-02-10 10:30:40.208675
27	1	Test Recipient Count Fix	Test dengan correct category data	Hello {name}, test dengan correct recipient count!	\N	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 10:37:53.846067	2026-02-10 10:37:58.14838	2026-02-10 10:29:26.990658	2026-02-10 10:37:53.869383
25	1	template	desc	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 10:38:26.830631	2026-02-10 10:38:31.436671	2026-02-10 10:09:34.959301	2026-02-10 10:38:26.891534
29	1	Bismillah	bismilla	check	\N	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 10:41:08.913052	2026-02-10 10:41:13.701526	2026-02-10 10:41:06.0756	2026-02-10 10:41:08.924019
14	1	Real WhatsApp Test	Test dengan Evolution API langsung	Hello {name}, ini adalah test pesan langsung ke Evolution API!	\N	{"search": "", "categories": ["kawan2"]}	completed_with_errors	1	0	1	\N	2026-02-10 04:08:23.315113	2026-02-10 04:08:23.356902	2026-02-10 04:08:16.150257	2026-02-10 04:08:23.328271
30	1	Bismillah	ds	bismillah	\N	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 11:03:18.962433	2026-02-10 11:03:24.234665	2026-02-10 11:03:16.366304	2026-02-10 11:03:18.988827
15	1	Real WhatsApp Test 2	Test dengan endpoint /send/message	Hello {name}, ini adalah test pesan dengan endpoint yang benar!	\N	{"search": "", "categories": ["kawan2"]}	completed_with_errors	1	0	1	\N	2026-02-10 04:13:08.562943	2026-02-10 04:13:08.57934	2026-02-10 04:12:58.496472	2026-02-10 04:13:08.568009
31	1	BIsmillah		BIsmillah	\N	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 11:28:46.234476	2026-02-10 11:28:49.683058	2026-02-10 11:28:43.000571	2026-02-10 11:28:46.260936
16	1	bism	d	Hello {name}, welcome to our service!	1	{"search": "", "categories": ["kawan2"]}	completed_with_errors	1	0	1	\N	2026-02-10 04:18:06.314291	2026-02-10 04:18:06.534346	2026-02-10 04:17:40.257963	2026-02-10 04:18:06.3447
17	1	Test dengan Device ID Mock	Test menggunakan hardcoded device ID	Hello {name}, test dengan device ID mock!	\N	{"search": "", "categories": ["kawan2"]}	completed_with_errors	1	0	1	\N	2026-02-10 04:21:17.114281	2026-02-10 04:21:17.154172	2026-02-10 04:21:07.045262	2026-02-10 04:21:17.132412
32	1	Bismillah	desc	BIsmillah	\N	{"search": "", "categories": ["kawan2"]}	completed	2	2	0	\N	2026-02-10 14:28:50.90284	2026-02-10 14:28:54.314243	2026-02-10 14:28:44.012592	2026-02-10 14:28:50.990759
\.


--
-- Data for Name: contact_categories; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.contact_categories (id, user_id, name, description, color, created_at, updated_at) FROM stdin;
1	1	Test Category	Test category for contacts	#ff5722	2026-02-09 09:21:25.515341	2026-02-09 09:21:25.515341
2	1	kawan2	desc	#d27219	2026-02-09 09:29:22.012276	2026-02-09 09:29:22.012276
5	1	New Test Category	New Test Description	#00FF00	2026-02-09 09:56:05.168126	2026-02-09 09:56:05.168126
\.


--
-- Data for Name: contact_category_relations; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.contact_category_relations (id, contact_id, category_id, created_at) FROM stdin;
9	24	2	2026-02-09 14:40:36.420637
14	27	1	2026-02-10 10:00:30.906045
15	27	2	2026-02-10 10:00:30.906045
16	28	2	2026-02-10 11:28:13.15237
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.contacts (id, user_id, name, phone, email, company, address, notes, created_at, updated_at, categories) FROM stdin;
24	1	zahirtamimi	+6281213775718	nswardana@gmail.com		Victoria sentul city		2026-02-09 10:15:16.008717	2026-02-09 14:40:36.420637	{kawan2}
27	1	NANANG SETYA WARDANA	+62818223304	nswardana@gmail.com	\N	49, JALAN TIMUR 6, BANDAR BARU ENSTEK, 71800 BANDAR BARU ENSTEK, NEGERI SEMBILAN,	\N	2026-02-10 10:00:30.906045	2026-02-10 10:27:40.893604	{"Test Category",kawan2}
28	1	Umu Laila	+6287874875768		\N	\N	\N	2026-02-10 11:28:13.15237	2026-02-10 11:28:13.15237	{}
\.


--
-- Data for Name: incoming_messages; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.incoming_messages (id, message_id, phone_id, device_id, sender_phone, sender_name, message_type, message_content, is_group, group_id, raw_payload, received_at, updated_at, is_revoked) FROM stdin;
\.


--
-- Data for Name: message_templates; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.message_templates (id, user_id, name, content, category, variables, is_active, created_at, updated_at) FROM stdin;
1	1	Welcome Message	Hello {{name}}! Welcome to our service. We are glad to have you with us!	welcome	["name"]	t	2026-02-08 15:23:22.44203	2026-02-08 15:23:22.44203
2	1	Order Confirmation	Dear {{name}}, your order #{{order_id}} has been confirmed. Total: {{amount}}.	notification	["name", "order_id", "amount"]	t	2026-02-08 15:23:22.44203	2026-02-08 15:23:22.44203
3	1	Flash Sale	🔥 FLASH SALE! Get {{discount}}% off on all items! Use code: {{promo_code}}.	promotion	["discount", "promo_code"]	t	2026-02-08 15:23:22.44203	2026-02-08 15:23:22.44203
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.messages (id, phone_number_id, message_id, from_number, to_number, message_type, content, media_url, media_type, status, webhook_sent, created_at, updated_at) FROM stdin;
76	8	3EB0BFDE387E044AC85C50	+62818223304	+6281213775718	text	wah	\N	\N	sent	f	2026-02-11 02:53:25.020383+00	2026-02-11 02:53:25.020383+00
77	8	test_direct	+6281213775718	8	text	halo 313	\N	\N	received	f	2026-02-11 03:06:52.455352+00	2026-02-11 03:06:52.455352+00
78	8	test_direct_final	+6281213775718	8	text	halo 314	\N	\N	received	f	2026-02-11 03:14:37.500534+00	2026-02-11 03:14:37.500534+00
79	8	debug_test_final	191534284673211	8	text	Debug test final	\N	\N	received	f	2025-02-11 07:27:24+00	2026-02-11 04:12:34.26453+00
80	8	test_device_id_fix	191534284673211	8	text	Testing device ID fix	\N	\N	received	f	2025-02-11 07:27:24+00	2026-02-11 04:16:38.208745+00
81	8	test_timestamp_fix	191534284673211	8	text	Testing timestamp fix	\N	\N	received	f	2026-02-11 04:18:25.133+00	2026-02-11 04:18:25.134222+00
82	8	A5794D2B4BFF24B4EB8F2B5798D6694E	6281213775718	8	text		\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:19:03.375491+00
83	8	test_final_fix	6281213775718	8	text	This should be ignored	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:20:23.424006+00
84	8	test_body_fix	6281213775718	8	text	Testing body field fix	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:20:48.871911+00
85	8	ACC3BE407F09247E91B05781DCDBF2ED	6281372196013	8	text		\N	\N	received	f	2026-02-11 04:20:56+00	2026-02-11 04:20:56.366927+00
86	8	ACC3BE407F09247E91B05781DCDBF2ED	6281372196013	8	text	Sdh dikurangi, naskun 20, nasgor 18, nasi liwet 12	\N	\N	received	f	2026-02-11 04:20:56+00	2026-02-11 04:20:56.391077+00
87	8	A5EA67BF46372C1E5C72E84A07A361E1	6281213775718	8	text	Halo 322	\N	\N	received	f	2026-02-11 04:21:18+00	2026-02-11 04:21:18.541972+00
88	8	A5678A396B5A96311A9D7D237A891451	6281213775718	8	text	Halo 333	\N	\N	received	f	2026-02-11 04:21:35+00	2026-02-11 04:21:35.050883+00
89	8	A54188BB93F2D7C3D0169DCB7B1707B4	6281213775718	8	text	Halo 334	\N	\N	received	f	2026-02-11 04:21:48+00	2026-02-11 04:21:48.869282+00
90	8	ACC878BEB3ED07EFBFCFE0821361A75B	6285282952664	8	text		\N	\N	received	f	2026-02-11 04:21:48+00	2026-02-11 04:21:48.894201+00
91	8	ACC878BEB3ED07EFBFCFE0821361A75B	6285282952664	8	text	Traktir basreng bg	\N	\N	received	f	2026-02-11 04:21:48+00	2026-02-11 04:21:48.91047+00
92	8	A597EFD9B97D18BE8B2AE59F6642EC0A	6281213775718	8	text	Halo 335	\N	\N	received	f	2026-02-11 04:22:47+00	2026-02-11 04:22:47.165556+00
93	8	AC85FEBE7E71F4B16A4ECAC48719F783	6287722442315	8	text	Iya udah sering kalau basreng mah	\N	\N	received	f	2026-02-11 04:23:44+00	2026-02-11 04:23:44.833268+00
94	8	AC85FEBE7E71F4B16A4ECAC48719F783	6287722442315	8	text		\N	\N	received	f	2026-02-11 04:23:44+00	2026-02-11 04:23:44.834818+00
95	8	test_autoreply_fix	6281213775718	8	text	Test auto reply fix	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:23:45.857637+00
96	8	A534455A59115109CED9CC3ACE269896	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:23:53+00	2026-02-11 04:23:53.203059+00
97	8	AC536C96217662EDB6F7465BBE22BF1D	6287874875768	8	text		\N	\N	received	f	2026-02-11 04:24:58+00	2026-02-11 04:25:02.213371+00
98	8	AC536C96217662EDB6F7465BBE22BF1D	6287874875768	8	text		\N	\N	received	f	2026-02-11 04:24:58+00	2026-02-11 04:25:02.533011+00
99	8	test_autoreply_final	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:25:11.709114+00
100	8	A5527BBAF73CACD24774AC64C97EAE0A	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:25:26+00	2026-02-11 04:25:26.32762+00
101	8	ACCDA8A64BA309C0A2428D446CA4B463	6287874875768	8	text	*GORO KEPERLUAN MAKAN MINUM/IURAN KEBAJIKAN SEKOLAH DASAR DAN SMP PPH  SENTUL*\n```\nRabu ,11 FEBRUARI 2026\n\n1. Iuran M Mujahid Waqar 500.000\n2.\n3. \n\n\nTerkumpul: Rp 000.000\n```\n\n*🏧BCA SITI NUR HANDAYANI* \n```5735222250```\n\nYa Allah tolonglah kami...\n🤲🤲🤲	\N	\N	received	f	2026-02-11 04:25:50+00	2026-02-11 04:25:50.323962+00
102	8	ACF8429989B092B81E2900877BA2621E	6287874875768	8	text		\N	\N	received	f	2026-02-11 04:26:21+00	2026-02-11 04:26:21.466477+00
103	8	ACF8429989B092B81E2900877BA2621E	6287874875768	8	text		\N	\N	received	f	2026-02-11 04:26:21+00	2026-02-11 04:26:21.838166+00
104	8	AC05C35E3D037E125D2FB353E93F6FD4	6287874875768	8	text	*GORO KEPERLUAN MAKAN MINUM/IURAN KEBAJIKAN SEKOLAH DASAR DAN SMP PPH  SENTUL*\n```\nRabu ,11 FEBRUARI 2026\n\n1. Iuran M Mujahid Waqar 500.000\n2.\n3. \n\n\nTerkumpul: Rp 500.000\n```\n\n*🏧BCA SITI NUR HANDAYANI* \n```5735222250```\n\nYa Allah tolonglah kami...\n🤲🤲🤲	\N	\N	received	f	2026-02-11 04:26:21+00	2026-02-11 04:26:21.908811+00
105	8	test_autoreply_send	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:26:43.306383+00
106	8	AC0338684EDA4937803F9857AD229C85	6282286452105	8	text		\N	\N	received	f	2026-02-11 04:26:51+00	2026-02-11 04:26:51.37694+00
107	8	AC0338684EDA4937803F9857AD229C85	6282286452105	8	text	*𝐎𝐌𝐒𝐄𝐓 𝟗 𝐑𝐄𝐒𝐓𝐎 𝐈𝐍𝐃𝐎𝐍𝐄𝐒𝐈𝐀*\n```\n🗓️SENIN, 09 FEBRUARI 2026\n\n1.R.BRIYANI   |310.000\n2.K.M MAMAK   |200.000\n3.M.SELERA    |331.000\n4.KBRC BEKASI |-\n5.H.CORNER    |1.301.920\n6.P.KULINER   |742.500\n7.GHC BANDUNG |526.400\n8.GHC SEMRANG |900.000\n9.R.BJIATEKA  |545.000\n```\n*TOTAL : Rp.4.856.820*	\N	\N	received	f	2026-02-11 04:26:51+00	2026-02-11 04:26:51.436488+00
108	8	AC6366AF08DFF5DB7CCC00F198526C2D	6282286452105	8	text		\N	\N	received	f	2026-02-11 04:28:15+00	2026-02-11 04:28:15.085426+00
109	8	AC6366AF08DFF5DB7CCC00F198526C2D	6282286452105	8	text	Iya	\N	\N	received	f	2026-02-11 04:28:15+00	2026-02-11 04:28:15.103271+00
110	8	test_autoreply_controller	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:29:01.484736+00
111	8	A5BD40A5791229E896FD41DE8B95300B	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:29:24+00	2026-02-11 04:29:24.702722+00
112	8	AC3CA4166304DD0175ECE565802344B6	6287874875768	8	text		\N	\N	received	f	2026-02-11 04:29:40+00	2026-02-11 04:29:40.689055+00
113	8	A5B0B818342B86000F630FDAE2AEB2B3	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:30:11+00	2026-02-11 04:30:11.981546+00
114	8	AC350BB02B655F93D319B0D83DEF0884	6285282952664	8	text	Gpp asalkan dia bahagia	\N	\N	received	f	2026-02-11 04:30:55+00	2026-02-11 04:30:55.189406+00
115	8	test_autoreply_fixed	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:30:59.377466+00
116	8	AC40CE9927D58B56D166400689EC26D3	6287722442315	8	text	Ok	\N	\N	received	f	2026-02-11 04:31:25+00	2026-02-11 04:31:25.211813+00
117	8	test_autoreply_final	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:31:58.886334+00
118	8	A5A351E40A0F40DAAB18785C928454D9	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:32:25+00	2026-02-11 04:32:25.708676+00
119	8	test_autoreply_connected	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:33:30.052801+00
120	8	3EB050788D10EC20271F39	+62818223304	6281213775718	text	Menu tidak ditemukan. Silakan pilih nomor yang tersedia atau ketik "0" untuk kembali ke menu utama.	\N	\N	sent	f	2026-02-11 04:33:33.049376+00	2026-02-11 04:33:33.049376+00
121	8	A5167D143F4F4CD704FDC314F995A041	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:33:50+00	2026-02-11 04:33:50.31568+00
122	8	3EB06445E84CCB17AEE89C	+62818223304	6281213775718	text	Menu tidak ditemukan. Silakan pilih nomor yang tersedia atau ketik "0" untuk kembali ke menu utama.	\N	\N	sent	f	2026-02-11 04:33:52.140591+00	2026-02-11 04:33:52.140591+00
123	8	A5D0EE9564348896F033E5E13C01A89D	6281213775718	8	text	Menu apa?	\N	\N	received	f	2026-02-11 04:33:58+00	2026-02-11 04:33:58.729458+00
124	8	A50A3C90722C4B97328F98BF9FEE2D05	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:34:04+00	2026-02-11 04:34:04.889971+00
125	8	3EB034D1C6E1F8F38A9DE5	+62818223304	6281213775718	text	Menu tidak ditemukan. Silakan pilih nomor yang tersedia atau ketik "0" untuk kembali ke menu utama.	\N	\N	sent	f	2026-02-11 04:34:06.845376+00	2026-02-11 04:34:06.845376+00
126	8	AC3C741E46A08DD129F583CDC609BCEF	6287874875768	8	text		\N	\N	received	f	2026-02-11 04:34:11+00	2026-02-11 04:34:11.736627+00
127	8	A53243FD16162D7B5A7027463699BB21	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:35:32+00	2026-02-11 04:35:32.872517+00
128	8	3EB06DB83DC29B4FFA0434	+62818223304	6281213775718	text	Menu tidak ditemukan. Silakan pilih nomor yang tersedia atau ketik "0" untuk kembali ke menu utama.	\N	\N	sent	f	2026-02-11 04:35:34.784018+00	2026-02-11 04:35:34.784018+00
129	8	A5420A3A18FE614A947F336D0C11C730	6281213775718	8	text	0	\N	\N	received	f	2026-02-11 04:37:03+00	2026-02-11 04:37:03.465361+00
130	8	A576F5D37A0519DB5ACD17430FF41193	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:37:36+00	2026-02-11 04:37:36.676166+00
131	8	3EB0497C12C71ABD37229A	+62818223304	6281213775718	text	Menu tidak ditemukan. Silakan pilih nomor yang tersedia atau ketik "0" untuk kembali ke menu utama.	\N	\N	sent	f	2026-02-11 04:37:38.582661+00	2026-02-11 04:37:38.582661+00
132	8	AC18FA9B3441BCE5164277CFF5D91A74	6287877633582	8	text	Terima kasih En Adib.	\N	\N	received	f	2026-02-11 04:38:52+00	2026-02-11 04:38:52.184693+00
133	8	test_autoreply_welcome	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:39:34.394379+00
134	8	3EB018D8C3B9D7505FDC75	+62818223304	6281213775718	text	halo juga	\N	\N	sent	f	2026-02-11 04:39:36.635889+00	2026-02-11 04:39:36.635889+00
135	8	AC3BF9C9B124A04C224C0C3D862A1979	628999171394	8	text		\N	\N	received	f	2026-02-11 04:39:55+00	2026-02-11 04:39:55.705798+00
136	8	AC3BF9C9B124A04C224C0C3D862A1979	628999171394	8	text	Terimakasih umi elis dan sazah fatimah..	\N	\N	received	f	2026-02-11 04:39:55+00	2026-02-11 04:39:55.717051+00
137	8	A525547CCF9028399194DF13F2C456F3	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:40:17+00	2026-02-11 04:40:17.323186+00
138	8	3EB0BE8A7D2A3FA61C81FB	+62818223304	6281213775718	text	halo juga	\N	\N	sent	f	2026-02-11 04:40:19.244949+00	2026-02-11 04:40:19.244949+00
139	8	AC75D4935662520156E8F598A61E6A1C	628999171394	8	text	Mohon izin Pak Adnan Pak Izbiq Pak Bahrum Abu Umi Sumayyah juga Umi2 Abi Bunda Ayah yg dikasih \nMohon izin untuk buka goro pintu asrama anak2 \nYa Allah tlng...\nBuget yg di perlukan 300 rb\nSilahkan Umi Abi Ayah Bunda  yg ada rezki lebih untum anak2..🤗🤲🤲🤲\nBCA a.n Loviyani \n2200245906\n\n\n1. Ghazi bayram 10.000 ✅\n2. Amira 50.000 ✅\n3. Salimah 50.000 ✅\n4. Nur ayu 20.000\n5. khodijah 50.000✅\n6. Nafisah 20.000✅\n7. Walidah 25.000✅\n\n\nTotal : Rp.225.000	\N	\N	received	f	2026-02-11 04:41:39+00	2026-02-11 04:41:39.875933+00
140	8	test_menu_processing	6281213775718	8	text	1	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:42:59.68857+00
141	8	A5339B79685410D49F1C31C378F86DC6	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:43:16+00	2026-02-11 04:43:16.510899+00
142	8	3EB04DA5730DBFC0D01210	+62818223304	6281213775718	text	halo juga	\N	\N	sent	f	2026-02-11 04:43:18.307901+00	2026-02-11 04:43:18.307901+00
143	8	A55600734AAE4766B17FF3E041F90ABE	6281213775718	8	text	1	\N	\N	received	f	2026-02-11 04:43:28+00	2026-02-11 04:43:28.706777+00
144	8	AC3B651F5AFB8C9620D55EC170ABEBA2	628999171394	8	text	Silahkan umi,abi dan wali murid,yg ada lebih rezki, yg  mau ambil berkat untuk goro pintu anak2 ,unterimakasih semua..🙏🙏	\N	\N	received	f	2026-02-11 04:43:40+00	2026-02-11 04:43:40.410131+00
145	8	3A26E9C497B52508E53E	60196712024	8	text	*🌙 PROMO SET IFTAR RAMADHAN 🌙*\n\nLokasi:\nDteratak Mercato Cafe, \nMercato, Bandar Baru Enstek, Nilai, NSDK\n\n\n🍽 Set Combo Nasi – RM17.90\n🍜 Set Menu Berkuah – RM15.90\n🍗 Set Iftar Western – dari RM19.90\n\n✨ Semua set termasuk:\n✔ 1 Menu Utama\n✔ 1 Minuman (Sejuk/Panas)\n✔ Kuih\n✔ Kurma\n\n⏰ Tempahan dibuka setiap hari\n3.30PM – 6.30PM\n\n📲 WhatsApp: 013-8994890\n\nBooking awal digalakkan!\nReply / WhatsApp sekarang untuk lock set anda.	\N	\N	received	f	2026-02-11 04:46:06+00	2026-02-11 04:46:06.332813+00
146	8	3A9CF3D5C08C2960773E	60196712024	8	text		\N	\N	received	f	2026-02-11 04:46:06+00	2026-02-11 04:46:07.165623+00
147	8	3AA4DDCBCF71F3C08B17	6282240063330	8	text		\N	\N	received	f	2026-02-11 04:46:14+00	2026-02-11 04:46:14.701268+00
148	8	3AA4DDCBCF71F3C08B17	6282240063330	8	text	Alhamdulillah, sedikit lagi ya	\N	\N	received	f	2026-02-11 04:46:14+00	2026-02-11 04:46:14.728193+00
149	8	test_menu_response	6281213775718	8	text	1	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 04:46:35.817935+00
150	8	A536623A279CBFFB506C357C877F9713	6287716404253	8	text		\N	\N	received	f	2026-02-11 04:46:49+00	2026-02-11 04:46:49.849634+00
151	8	A524F64744FE9BD46D5E2AD021593D17	6287716404253	8	text		\N	\N	received	f	2026-02-11 04:46:51+00	2026-02-11 04:46:52.080075+00
152	8	3A232CB01925CFD1C6D0	6282240063330	8	text	Ayo bapak2, ibu2 yang ada rezekinya sedikit pun tidak apa-apa	\N	\N	received	f	2026-02-11 04:46:54+00	2026-02-11 04:46:54.042136+00
153	8	2A9A10142582248CB3BA	62895351085680	8	text		\N	\N	received	f	2026-02-11 04:47:05+00	2026-02-11 04:47:05.731558+00
154	8	2A9A10142582248CB3BA	62895351085680	8	text		\N	\N	received	f	2026-02-11 04:47:05+00	2026-02-11 04:47:06.356034+00
155	8	AC3DD5A3A01C6B7878BB44465E52B4FB	6285933601150	8	text		\N	\N	received	f	2026-02-11 04:47:25+00	2026-02-11 04:47:25.280565+00
156	8	AC3DD5A3A01C6B7878BB44465E52B4FB	6285933601150	8	text		\N	\N	received	f	2026-02-11 04:47:25+00	2026-02-11 04:47:26.13946+00
157	8	3A4988823B99D059AD80	60196712024	8	text	Siapa yg boleh tlg buat kn dlm bentuk viceo nya?	\N	\N	received	f	2026-02-11 04:47:56+00	2026-02-11 04:47:56.318896+00
158	8	3A4B1C62131A905E1C0B	60196712024	8	text		\N	\N	received	f	2026-02-11 04:48:16+00	2026-02-11 04:48:17.485744+00
159	8	AC867935D9FD1EA079F2468840697D1A	628114814313	8	text		\N	\N	received	f	2026-02-11 04:48:37+00	2026-02-11 04:48:37.653975+00
160	8	AC867935D9FD1EA079F2468840697D1A	628114814313	8	text	Boleh besok atau malam ini? Ana minta izin cadang selepas Dzuhur ini akan ke Jakarta urusan kontrak ruko bersama P dr Arfan Bu.	\N	\N	received	f	2026-02-11 04:48:37+00	2026-02-11 04:48:37.69581+00
161	8	ACBB67EF1DE55154E74B3FB860787025	6287874875768	8	text	*GORO KEPERLUAN MAKAN MINUM/IURAN KEBAJIKAN SEKOLAH DASAR DAN SMP PPH  SENTUL*\n```\nRabu ,11 FEBRUARI 2026\n\n1. Iuran M Mujahid Waqar 500.000\n2. Iuran Ibrahim Agiston 100.000\n3. Iuran Ismail Hendra 100.000\n\n\nTerkumpul: Rp 700.000\n```\n\n*🏧BCA SITI NUR HANDAYANI* \n```5735222250```\n\nYa Allah tolonglah kami...\n🤲🤲🤲	\N	\N	received	f	2026-02-11 04:51:21+00	2026-02-11 04:51:22.012957+00
162	8	AC9444674A963DD08DA903D9534DDA77	6287874875768	8	text		\N	\N	received	f	2026-02-11 04:51:33+00	2026-02-11 04:51:33.173932+00
163	8	AC9444674A963DD08DA903D9534DDA77	6287874875768	8	text	*GORO KEPERLUAN MAKAN MINUM/IURAN KEBAJIKAN SEKOLAH DASAR DAN SMP PPH  SENTUL*\n```\nRabu ,11 FEBRUARI 2026\n\n1. Iuran M Mujahid Waqar 500.000\n2. Iuran Ibrahim Agiston 100.000\n3. Iuran Ismail Hendra 100.000\n\n\nTerkumpul: Rp 700.000\n```\n\n*🏧BCA SITI NUR HANDAYANI* \n```5735222250```\n\nYa Allah tolonglah kami...\n🤲🤲🤲	\N	\N	received	f	2026-02-11 04:51:33+00	2026-02-11 04:51:33.208914+00
164	8	AC12ECA0B73C47AB834CDED3872A7211	628114814313	8	text	Misal besok jam 8 atau jam 9 pagi Bu	\N	\N	received	f	2026-02-11 04:54:44+00	2026-02-11 04:54:44.127348+00
165	8	AC172489ED23C991ADDDE9DEADA6E37E	6289620276373	8	text		\N	\N	received	f	2026-02-11 04:54:46+00	2026-02-11 04:54:46.167631+00
166	8	AC172489ED23C991ADDDE9DEADA6E37E	6289620276373	8	text	Bapak ibu marilah sama' kita ambil tanggung jawab u keperluan anak²kita	\N	\N	received	f	2026-02-11 04:54:46+00	2026-02-11 04:54:46.191833+00
167	8	AC2B4487DA50B015F865B2E92648F9F9	628980531395	8	text		\N	\N	received	f	2026-02-11 04:54:48+00	2026-02-11 04:54:48.62363+00
168	8	AC2B4487DA50B015F865B2E92648F9F9	628980531395	8	text	Ampun ya Allah...	\N	\N	received	f	2026-02-11 04:54:48+00	2026-02-11 04:54:48.62747+00
169	8	AC3D74114E7B8B483492F0E1BB9BBD2E	6289696392478	8	text		\N	\N	received	f	2026-02-11 04:56:06+00	2026-02-11 04:56:06.288032+00
170	8	AC3D74114E7B8B483492F0E1BB9BBD2E	6289696392478	8	text	Maaf, lauk nya sudah siap , boleh tolong di bantu pengantarannya.\nSyukron ..	\N	\N	received	f	2026-02-11 04:56:06+00	2026-02-11 04:56:06.39432+00
171	8	AC5BCF3E0532723F2D8B901D43193B05	6281372196013	8	text	Alhamdulillah, Sedekah Jumat Berkah dari ibu Lenny dan keluarga, mhn doa jg utk pak M Ridwan suami bu Lenny, yg sdg sakit	\N	\N	received	f	2026-02-11 04:56:17+00	2026-02-11 04:56:17.518143+00
172	8	AC963F1A4B8F292B06202CE2B5F971F3	6281372196013	8	text		\N	\N	received	f	2026-02-11 04:56:17+00	2026-02-11 04:56:17.596203+00
173	8	A53DD354B42E4087CB90D739AB085B7F	628814176521	8	text		\N	\N	received	f	2026-02-11 04:56:26+00	2026-02-11 04:56:26.045325+00
174	8	A53DD354B42E4087CB90D739AB085B7F	628814176521	8	text		\N	\N	received	f	2026-02-11 04:56:26+00	2026-02-11 04:56:26.771695+00
175	8	ACA64CCFC7B822FA54B8ABE551E4258C	628980531395	8	text	Besok mau buat berapa2	\N	\N	received	f	2026-02-11 04:57:15+00	2026-02-11 04:57:15.664416+00
176	8	AC57BA0A7E88382E2E64C723DC77B2EF	628114814313	8	text		\N	\N	received	f	2026-02-11 04:57:41+00	2026-02-11 04:57:41.308777+00
177	8	AC57BA0A7E88382E2E64C723DC77B2EF	628114814313	8	text	ya Allah berilah kesehatan kpd Pak Ridwan...	\N	\N	received	f	2026-02-11 04:57:41+00	2026-02-11 04:57:41.31204+00
178	8	A5ED296E7F7059EDF4A459692BB46171	628814176521	8	text	Ya Allah tolong..🤲🏻🤲🏻🤲🏻	\N	\N	received	f	2026-02-11 04:57:41+00	2026-02-11 04:57:41.605497+00
179	8	A567C7F10C94B17D951D26605D03B06A	628814176521	8	text		\N	\N	received	f	2026-02-11 04:57:47+00	2026-02-11 04:57:47.44092+00
180	8	A567C7F10C94B17D951D26605D03B06A	628814176521	8	text		\N	\N	received	f	2026-02-11 04:57:47+00	2026-02-11 04:57:48.302219+00
181	8	AC4A5DF5A7A0C5E31430073F7DF01EAE	628980531395	8	text	*DJP *\nMie Mamak :\nTT :\nRC + MARTABAK : \n\n*KEJAKSAAN*\nMie Mamak :\nTT :\nRC + MARTABAK :	\N	\N	received	f	2026-02-11 04:58:43+00	2026-02-11 04:58:43.122363+00
182	8	AC78CD879FF79656C3B9BE617ECBD6BA	6281372196013	8	text	Aamiin ya Allah	\N	\N	received	f	2026-02-11 04:58:55+00	2026-02-11 04:58:55.11717+00
183	8	A5978C32C188E42CA26C9A2B6150A296	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:59:28+00	2026-02-11 04:59:28.266506+00
184	8	3EB04B7CFBC536DD013FE5	+62818223304	6281213775718	text	halo juga	\N	\N	sent	f	2026-02-11 04:59:31.831548+00	2026-02-11 04:59:31.831548+00
185	8	A5AE3E300A06419235AA42A2F363137B	6281213775718	8	text	Menus	\N	\N	received	f	2026-02-11 04:59:35+00	2026-02-11 04:59:35.227484+00
186	8	test_menu_selection	6281213775718	8	text	1	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 05:00:58.543626+00
187	8	AC514BC6050A77883506AD1BD2F4236E	6281372196013	8	text	CAFE POJOK KULINER\n\nRABU, 11/02/2026\n\n06.30 am-\n07.30 am- \n08.00 am-\n08.55 am-\nRp. 612.000\n09.00 am-\n09.50 am-\n10.00 am-\n10.45 am-\n11.00 am-\n11.20 pm-\n12.00 pm-\nRp. 1.161.000\n01.30 pm-\n02.30 pm-\n03.30 pm-\n05.30 pm-\n06.00 pm-\n07.00 pm-\n08.00 pm-\n09.00 pm-\n10.00 pm-\n11.00 pm -\n\nOmset Semasa :\nRp 1.161.000\n\nTarget Rp.3.000.000	\N	\N	received	f	2026-02-11 05:01:14+00	2026-02-11 05:01:14.719042+00
188	8	test_menu_fixed	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 05:02:18.138805+00
189	8	3EB03FC96C1A994282088B	+62818223304	6281213775718	text	halo juga	\N	\N	sent	f	2026-02-11 05:02:20.81874+00	2026-02-11 05:02:20.81874+00
190	8	test_menu_selection_fixed	6281213775718	8	text	1	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 05:02:25.207606+00
191	8	AC5F6D355566B32BD01B8434284F9732	628118047313	8	text		\N	\N	received	f	2026-02-11 05:02:51+00	2026-02-11 05:02:51.319911+00
192	8	AC5F6D355566B32BD01B8434284F9732	628118047313	8	text	Besok aja ya.jam 9	\N	\N	received	f	2026-02-11 05:02:51+00	2026-02-11 05:02:51.345899+00
193	8	ACA62A1B8A04662F6F549A57B5AC7F58	628118047313	8	text	Harap semua kwn2 dpt hadir	\N	\N	received	f	2026-02-11 05:03:08+00	2026-02-11 05:03:08.451919+00
194	8	test_welcome_with_menu	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 05:03:49.251427+00
195	8	3EB022D782A7D9873B8095	+62818223304	6281213775718	text	halo juga\n\nSilakan pilih:\n1. Roti Canai\n2. Roti Prata\n\nKetik "0" untuk kembali ke menu utama	\N	\N	sent	f	2026-02-11 05:03:51.534256+00	2026-02-11 05:03:51.534256+00
196	8	ACFEA643A6B739F4BEDF5C6998B12F4D	6281372196013	8	text		\N	\N	received	f	2026-02-11 05:03:52+00	2026-02-11 05:03:52.474621+00
197	8	ACFEA643A6B739F4BEDF5C6998B12F4D	6281372196013	8	text	Insya Allah ibu	\N	\N	received	f	2026-02-11 05:03:52+00	2026-02-11 05:03:52.559723+00
198	8	A55ADE5FF7302FDDED753CC090D75336	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 05:04:14+00	2026-02-11 05:04:14.499286+00
199	8	ACE4369701A9A9F7DA29E3377BD6DBFA	6281372196013	8	text		\N	\N	received	f	2026-02-11 05:04:15+00	2026-02-11 05:04:15.758346+00
200	8	ACE4369701A9A9F7DA29E3377BD6DBFA	6281372196013	8	text		\N	\N	received	f	2026-02-11 05:04:15+00	2026-02-11 05:04:16.077169+00
201	8	AC139766CCBD5A1D0262864FBC71E4E1	6281372196013	8	text	Alhamdulillah, Sedekah Jumat Berkah dari ibu Lenny dan keluarga, mhn doa jg utk pak M Ridwan suami bu Lenny, yg sdg sakit	\N	\N	received	f	2026-02-11 05:04:16+00	2026-02-11 05:04:16.102306+00
202	8	3EB0AD0A5182B4081BFACB	+62818223304	6281213775718	text	halo juga\n\nSilakan pilih:\n1. Roti Canai\n2. Roti Prata\n\nKetik "0" untuk kembali ke menu utama	\N	\N	sent	f	2026-02-11 05:04:16.851408+00	2026-02-11 05:04:16.851408+00
203	8	A52B9575091B958DD8BBBD7187C6F76A	6281213775718	8	text	1	\N	\N	received	f	2026-02-11 05:04:20+00	2026-02-11 05:04:20.963102+00
204	8	AC3F769476FC4D1FD970C557A302B5AB	628118047313	8	text		\N	\N	received	f	2026-02-11 05:04:54+00	2026-02-11 05:04:54.328066+00
205	8	AC3F769476FC4D1FD970C557A302B5AB	628118047313	8	text	Alhamdulillah.	\N	\N	received	f	2026-02-11 05:04:54+00	2026-02-11 05:04:54.368024+00
206	8	AC72896D61952648E24590DF67AD1B6F	628118047313	8	text	Smg Allah beri kesehatan unt p Ridwan.Lahir Bathin	\N	\N	received	f	2026-02-11 05:05:09+00	2026-02-11 05:05:09.055215+00
207	8	ACF707811F67536F663D2F0CEF30C4AB	6285933601150	8	text	*DJP *\nMie Mamak :15\nTT : 12\nRC + MARTABAK : 8+6\n\n*KEJAKSAAN*\nMie Mamak :10\nTT :10\nRC + MARTABAK :6+8	\N	\N	received	f	2026-02-11 05:05:16+00	2026-02-11 05:05:17.004364+00
208	8	test_menu_debug	6281213775718	8	text	1	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 05:06:02.894789+00
209	8	AC1802412EF6AEFBE6F8238E5B7E27AB	6285156277386	8	text		\N	\N	received	f	2026-02-11 05:06:07+00	2026-02-11 05:06:07.943714+00
210	8	AC1802412EF6AEFBE6F8238E5B7E27AB	6285156277386	8	text	Wilujeng tepang taun Ayi Fitri, barakallah fii umrik panjang umur sehat salawasna... Aamiin YRA 🤲🎂	\N	\N	received	f	2026-02-11 05:06:07+00	2026-02-11 05:06:08.09859+00
211	8	test_menu_debug_enhanced	6281213775718	8	text	1	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 05:06:46.704399+00
212	8	test_menu_working	6281213775718	8	text	1	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 05:07:49.178808+00
213	8	ACB27584EF9DCCBE1CEBE0CC5E2F9EF2	6281372196013	8	text	Aamiin ya Allah.. Syukran doanya ibu..	\N	\N	received	f	2026-02-11 05:07:50+00	2026-02-11 05:07:50.45878+00
214	8	test_menu_final_test	6281213775718	8	text	1	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 05:08:54.621789+00
215	8	A5D2A997E2F2A9D9C2E88324FE5391F6	6281931311113	8	text		\N	\N	received	f	2026-02-11 05:09:58+00	2026-02-11 05:09:58.537354+00
216	8	A5D2A997E2F2A9D9C2E88324FE5391F6	6281931311113	8	text	RESTORAN HARAPAN CORNER SENTUL BOGOR, \nRabu , 11 Februari 2026\n\n07.00am  - 0\n08.00am  - 0\n09.00am  - Rp.238.700\n10.00am  - 0\n11.00am  - 0\n12.00pm  - Rp.358.900\n01.00pm  - 0\n02.00pm  - 0\n03.00pm  -0\n04.00pm  -0\n05.00pm  -0\n06.00pm  -0\n07.00pm  -0\n08.00pm  -0\n09.00pm  -0\n10.00pm  -0\n \nJualan Semasa : Rp.358.900\nTarget : Rp7.00.000\n\nYa Allah tolong meriahkanlah lahir dan bathin kami...🤲🤲🤲	\N	\N	received	f	2026-02-11 05:09:58+00	2026-02-11 05:09:58.680905+00
217	8	A5586BEFFC818678199CC20E8E98CEF0	6281931311113	8	text	Ya Allah tolong 🤲🤲🤲	\N	\N	received	f	2026-02-11 05:10:11+00	2026-02-11 05:10:11.523161+00
218	8	A52B21510F630279018E59001BE3C604	6281931311113	8	text		\N	\N	received	f	2026-02-11 05:10:19+00	2026-02-11 05:10:19.773117+00
219	8	A52B21510F630279018E59001BE3C604	6281931311113	8	text	RESTORAN HARAPAN CORNER SENTUL BOGOR, \nRabu , 11 Februari 2026\n\n07.00am  - 0\n08.00am  - 0\n09.00am  - Rp.238.700\n10.00am  - 0\n11.00am  - 0\n12.00pm  - Rp.358.900\n01.00pm  - 0\n02.00pm  - 0\n03.00pm  -0\n04.00pm  -0\n05.00pm  -0\n06.00pm  -0\n07.00pm  -0\n08.00pm  -0\n09.00pm  -0\n10.00pm  -0\n \nJualan Semasa : Rp.358.900\nTarget : Rp7.00.000\n\nYa Allah tolong meriahkanlah lahir dan bathin kami...🤲🤲🤲	\N	\N	received	f	2026-02-11 05:10:19+00	2026-02-11 05:10:19.890814+00
220	8	A58A9E74A758AC2F1574FBBC49F30FE7	6281931311113	8	text	Ya Allah tolong 🤲🤲🤲	\N	\N	received	f	2026-02-11 05:10:20+00	2026-02-11 05:10:20.345872+00
221	8	A507554EA26CA912EE988C8A1F1A605B	6281931311113	8	text		\N	\N	received	f	2026-02-11 05:10:20+00	2026-02-11 05:10:20.694536+00
222	8	A507554EA26CA912EE988C8A1F1A605B	6281931311113	8	text	RESTORAN HARAPAN CORNER SENTUL BOGOR, \nRabu , 11 Februari 2026\n\n07.00am  - 0\n08.00am  - 0\n09.00am  - Rp.238.700\n10.00am  - 0\n11.00am  - 0\n12.00pm  - Rp.358.900\n01.00pm  - 0\n02.00pm  - 0\n03.00pm  -0\n04.00pm  -0\n05.00pm  -0\n06.00pm  -0\n07.00pm  -0\n08.00pm  -0\n09.00pm  -0\n10.00pm  -0\n \nJualan Semasa : Rp.358.900\nTarget : Rp7.00.000\n\nYa Allah tolong meriahkanlah lahir dan bathin kami...🤲🤲🤲	\N	\N	received	f	2026-02-11 05:10:20+00	2026-02-11 05:10:20.780277+00
223	8	A56F17F45EB786EEB1601878C6142E98	6281931311113	8	text	Ya Allah tolong 🤲🤲🤲	\N	\N	received	f	2026-02-11 05:10:21+00	2026-02-11 05:10:21.297829+00
247	8	test_halo_debug	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 05:16:13.93116+00
248	8	3EB064FF129B36E43C44EC	+62818223304	6281213775718	text	halo juga\n\nSilakan pilih:\n1. Roti Canai\n2. Roti Prata\n\nKetik "0" untuk kembali ke menu utama	\N	\N	sent	f	2026-02-11 05:16:17.491846+00	2026-02-11 05:16:17.491846+00
249	8	test_halo_final	6281213775718	8	text	halo	\N	\N	received	f	2026-02-11 04:19:03+00	2026-02-11 05:17:06.137652+00
\.


--
-- Data for Name: phone_numbers; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.phone_numbers (id, user_id, phone_number, device_name, token, webhook_url, webhook_secret, is_connected, last_seen, qr_code, session_data, auto_reply, auto_mark_read, auto_download_media, created_at, updated_at, evolution_instance) FROM stdin;
8	1	+62818223304	chatflow-api-1	token_35c231d5c39246eaa31eccc84126694c	https://evolution-api.beeasy.id/webhook	313313	t	2026-02-11 04:33:22.139239+00	http://localhost:8081/statics/qrcode/scan-qr-7551e63c-16b6-429e-bec0-f2c1cf7729c4.png	\N	\N	f	t	2026-02-11 02:48:06.665208+00	2026-02-11 04:33:22.139239+00	\N
\.


--
-- Data for Name: rate_limits; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.rate_limits (id, user_id, window_start, request_count, limit_per_hour, created_at) FROM stdin;
\.


--
-- Data for Name: scheduled_messages; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.scheduled_messages (id, user_id, phone_id, recipient, message, scheduled_at, status, sent_at, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.users (id, username, email, password_hash, api_key, jwt_secret, is_active, created_at, updated_at) FROM stdin;
1	admin	admin@example.com	$2a$12$d87mP4MWIwmRBrzAHKnw0uIsOzIX07L74ixrvbOKWq4Yk/mYKdXSC	MySecureEvolutionKey2024!	random_jwt_secret_string_123	t	2026-02-08 15:12:25.028631+00	2026-02-08 15:31:53.092781+00
2	testuser	test@example.com	$2a$12$X6LnYjWS0innf36gqL41dOf3DoV7DqsL0.g4COX1Q2NfS0vEESEj2	test-api-key	test-jwt-secret	t	2026-02-08 15:31:26.131189+00	2026-02-11 01:12:09.251077+00
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: chatflow_user
--

COPY public.webhook_events (id, phone_number_id, event_type, payload, retry_count, status, sent_at, created_at) FROM stdin;
\.


--
-- Name: api_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.api_usage_id_seq', 1, false);


--
-- Name: auto_reply_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.auto_reply_configs_id_seq', 3, true);


--
-- Name: auto_reply_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.auto_reply_logs_id_seq', 49, true);


--
-- Name: auto_reply_menus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.auto_reply_menus_id_seq', 12, true);


--
-- Name: auto_reply_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.auto_reply_sessions_id_seq', 7, true);


--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.broadcast_messages_id_seq', 1, false);


--
-- Name: broadcast_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.broadcast_progress_id_seq', 1, false);


--
-- Name: broadcast_recipients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.broadcast_recipients_id_seq', 31, true);


--
-- Name: broadcast_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.broadcast_templates_id_seq', 1, true);


--
-- Name: broadcasts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.broadcasts_id_seq', 32, true);


--
-- Name: contact_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.contact_categories_id_seq', 6, true);


--
-- Name: contact_category_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.contact_category_relations_id_seq', 16, true);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.contacts_id_seq', 28, true);


--
-- Name: incoming_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.incoming_messages_id_seq', 1, true);


--
-- Name: message_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.message_templates_id_seq', 3, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.messages_id_seq', 249, true);


--
-- Name: phone_numbers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.phone_numbers_id_seq', 8, true);


--
-- Name: rate_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.rate_limits_id_seq', 1, false);


--
-- Name: scheduled_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.scheduled_messages_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: webhook_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chatflow_user
--

SELECT pg_catalog.setval('public.webhook_events_id_seq', 1, false);


--
-- Name: api_usage api_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.api_usage
    ADD CONSTRAINT api_usage_pkey PRIMARY KEY (id);


--
-- Name: auto_reply_configs auto_reply_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_configs
    ADD CONSTRAINT auto_reply_configs_pkey PRIMARY KEY (id);


--
-- Name: auto_reply_logs auto_reply_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_logs
    ADD CONSTRAINT auto_reply_logs_pkey PRIMARY KEY (id);


--
-- Name: auto_reply_menus auto_reply_menus_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_menus
    ADD CONSTRAINT auto_reply_menus_pkey PRIMARY KEY (id);


--
-- Name: auto_reply_sessions auto_reply_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_sessions
    ADD CONSTRAINT auto_reply_sessions_pkey PRIMARY KEY (id);


--
-- Name: broadcast_messages broadcast_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_messages
    ADD CONSTRAINT broadcast_messages_pkey PRIMARY KEY (id);


--
-- Name: broadcast_progress broadcast_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_progress
    ADD CONSTRAINT broadcast_progress_pkey PRIMARY KEY (id);


--
-- Name: broadcast_recipients broadcast_recipients_broadcast_id_contact_id_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_broadcast_id_contact_id_key UNIQUE (broadcast_id, contact_id);


--
-- Name: broadcast_recipients broadcast_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_pkey PRIMARY KEY (id);


--
-- Name: broadcast_templates broadcast_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_templates
    ADD CONSTRAINT broadcast_templates_pkey PRIMARY KEY (id);


--
-- Name: broadcasts broadcasts_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcasts
    ADD CONSTRAINT broadcasts_pkey PRIMARY KEY (id);


--
-- Name: contact_categories contact_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_categories
    ADD CONSTRAINT contact_categories_pkey PRIMARY KEY (id);


--
-- Name: contact_categories contact_categories_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_categories
    ADD CONSTRAINT contact_categories_user_id_name_key UNIQUE (user_id, name);


--
-- Name: contact_category_relations contact_category_relations_contact_id_category_id_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_category_relations
    ADD CONSTRAINT contact_category_relations_contact_id_category_id_key UNIQUE (contact_id, category_id);


--
-- Name: contact_category_relations contact_category_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_category_relations
    ADD CONSTRAINT contact_category_relations_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_user_id_phone_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_user_id_phone_key UNIQUE (user_id, phone);


--
-- Name: incoming_messages incoming_messages_message_id_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.incoming_messages
    ADD CONSTRAINT incoming_messages_message_id_key UNIQUE (message_id);


--
-- Name: incoming_messages incoming_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.incoming_messages
    ADD CONSTRAINT incoming_messages_pkey PRIMARY KEY (id);


--
-- Name: message_templates message_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: phone_numbers phone_numbers_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.phone_numbers
    ADD CONSTRAINT phone_numbers_pkey PRIMARY KEY (id);


--
-- Name: phone_numbers phone_numbers_token_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.phone_numbers
    ADD CONSTRAINT phone_numbers_token_key UNIQUE (token);


--
-- Name: phone_numbers phone_numbers_user_id_phone_number_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.phone_numbers
    ADD CONSTRAINT phone_numbers_user_id_phone_number_key UNIQUE (user_id, phone_number);


--
-- Name: rate_limits rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_pkey PRIMARY KEY (id);


--
-- Name: rate_limits rate_limits_user_id_window_start_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_user_id_window_start_key UNIQUE (user_id, window_start);


--
-- Name: scheduled_messages scheduled_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_pkey PRIMARY KEY (id);


--
-- Name: users users_api_key_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_api_key_key UNIQUE (api_key);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: idx_api_usage_created_at; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_api_usage_created_at ON public.api_usage USING btree (created_at);


--
-- Name: idx_api_usage_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_api_usage_user_id ON public.api_usage USING btree (user_id);


--
-- Name: idx_auto_reply_configs_active; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_configs_active ON public.auto_reply_configs USING btree (is_active);


--
-- Name: idx_auto_reply_configs_phone_numbers; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_configs_phone_numbers ON public.auto_reply_configs USING gin (phone_numbers);


--
-- Name: idx_auto_reply_configs_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_configs_user_id ON public.auto_reply_configs USING btree (user_id);


--
-- Name: idx_auto_reply_logs_created; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_logs_created ON public.auto_reply_logs USING btree (created_at);


--
-- Name: idx_auto_reply_logs_phone; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_logs_phone ON public.auto_reply_logs USING btree (phone_number);


--
-- Name: idx_auto_reply_menus_config_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_menus_config_id ON public.auto_reply_menus USING btree (config_id);


--
-- Name: idx_auto_reply_menus_parent_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_menus_parent_id ON public.auto_reply_menus USING btree (parent_menu_id);


--
-- Name: idx_auto_reply_sessions_active; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_sessions_active ON public.auto_reply_sessions USING btree (is_active);


--
-- Name: idx_auto_reply_sessions_phone; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_sessions_phone ON public.auto_reply_sessions USING btree (phone_number);


--
-- Name: idx_auto_reply_sessions_phone_number_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_auto_reply_sessions_phone_number_id ON public.auto_reply_sessions USING btree (phone_number_id);


--
-- Name: idx_broadcast_messages_broadcast_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_broadcast_messages_broadcast_id ON public.broadcast_messages USING btree (broadcast_id);


--
-- Name: idx_broadcast_messages_status; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_broadcast_messages_status ON public.broadcast_messages USING btree (status);


--
-- Name: idx_broadcast_progress_broadcast_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_broadcast_progress_broadcast_id ON public.broadcast_progress USING btree (broadcast_id);


--
-- Name: idx_broadcast_templates_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_broadcast_templates_user_id ON public.broadcast_templates USING btree (user_id);


--
-- Name: idx_broadcasts_status; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_broadcasts_status ON public.broadcasts USING btree (status);


--
-- Name: idx_broadcasts_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_broadcasts_user_id ON public.broadcasts USING btree (user_id);


--
-- Name: idx_contact_categories_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_contact_categories_user_id ON public.contact_categories USING btree (user_id);


--
-- Name: idx_contact_relations_category_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_contact_relations_category_id ON public.contact_category_relations USING btree (category_id);


--
-- Name: idx_contact_relations_contact_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_contact_relations_contact_id ON public.contact_category_relations USING btree (contact_id);


--
-- Name: idx_contacts_phone; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_contacts_phone ON public.contacts USING btree (phone);


--
-- Name: idx_contacts_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_contacts_user_id ON public.contacts USING btree (user_id);


--
-- Name: idx_incoming_messages_device_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_incoming_messages_device_id ON public.incoming_messages USING btree (device_id);


--
-- Name: idx_incoming_messages_phone_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_incoming_messages_phone_id ON public.incoming_messages USING btree (phone_id);


--
-- Name: idx_incoming_messages_received_at; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_incoming_messages_received_at ON public.incoming_messages USING btree (received_at);


--
-- Name: idx_incoming_messages_sender_phone; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_incoming_messages_sender_phone ON public.incoming_messages USING btree (sender_phone);


--
-- Name: idx_messages_created_at; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_messages_created_at ON public.messages USING btree (created_at);


--
-- Name: idx_messages_phone_number_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_messages_phone_number_id ON public.messages USING btree (phone_number_id);


--
-- Name: idx_messages_status; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_messages_status ON public.messages USING btree (status);


--
-- Name: idx_phone_numbers_token; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_phone_numbers_token ON public.phone_numbers USING btree (token);


--
-- Name: idx_phone_numbers_user_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_phone_numbers_user_id ON public.phone_numbers USING btree (user_id);


--
-- Name: idx_rate_limits_user_window; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_rate_limits_user_window ON public.rate_limits USING btree (user_id, window_start);


--
-- Name: idx_scheduled_messages_scheduled_at; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_scheduled_messages_scheduled_at ON public.scheduled_messages USING btree (scheduled_at);


--
-- Name: idx_scheduled_messages_status; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_scheduled_messages_status ON public.scheduled_messages USING btree (status);


--
-- Name: idx_users_api_key; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_users_api_key ON public.users USING btree (api_key);


--
-- Name: idx_webhook_events_phone_number_id; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_webhook_events_phone_number_id ON public.webhook_events USING btree (phone_number_id);


--
-- Name: idx_webhook_events_status; Type: INDEX; Schema: public; Owner: chatflow_user
--

CREATE INDEX idx_webhook_events_status ON public.webhook_events USING btree (status);


--
-- Name: auto_reply_configs update_auto_reply_configs_updated_at; Type: TRIGGER; Schema: public; Owner: chatflow_user
--

CREATE TRIGGER update_auto_reply_configs_updated_at BEFORE UPDATE ON public.auto_reply_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: messages update_messages_updated_at; Type: TRIGGER; Schema: public; Owner: chatflow_user
--

CREATE TRIGGER update_messages_updated_at BEFORE UPDATE ON public.messages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: phone_numbers update_phone_numbers_updated_at; Type: TRIGGER; Schema: public; Owner: chatflow_user
--

CREATE TRIGGER update_phone_numbers_updated_at BEFORE UPDATE ON public.phone_numbers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: chatflow_user
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: api_usage api_usage_phone_number_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.api_usage
    ADD CONSTRAINT api_usage_phone_number_id_fkey FOREIGN KEY (phone_number_id) REFERENCES public.phone_numbers(id) ON DELETE CASCADE;


--
-- Name: api_usage api_usage_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.api_usage
    ADD CONSTRAINT api_usage_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auto_reply_configs auto_reply_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_configs
    ADD CONSTRAINT auto_reply_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: auto_reply_logs auto_reply_logs_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_logs
    ADD CONSTRAINT auto_reply_logs_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auto_reply_sessions(id);


--
-- Name: auto_reply_menus auto_reply_menus_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_menus
    ADD CONSTRAINT auto_reply_menus_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.auto_reply_configs(id) ON DELETE CASCADE;


--
-- Name: auto_reply_menus auto_reply_menus_parent_menu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_menus
    ADD CONSTRAINT auto_reply_menus_parent_menu_id_fkey FOREIGN KEY (parent_menu_id) REFERENCES public.auto_reply_menus(id);


--
-- Name: auto_reply_sessions auto_reply_sessions_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_sessions
    ADD CONSTRAINT auto_reply_sessions_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.auto_reply_configs(id);


--
-- Name: auto_reply_sessions auto_reply_sessions_current_menu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_sessions
    ADD CONSTRAINT auto_reply_sessions_current_menu_id_fkey FOREIGN KEY (current_menu_id) REFERENCES public.auto_reply_menus(id);


--
-- Name: auto_reply_sessions auto_reply_sessions_phone_number_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.auto_reply_sessions
    ADD CONSTRAINT auto_reply_sessions_phone_number_id_fkey FOREIGN KEY (phone_number_id) REFERENCES public.phone_numbers(id);


--
-- Name: broadcast_messages broadcast_messages_broadcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_messages
    ADD CONSTRAINT broadcast_messages_broadcast_id_fkey FOREIGN KEY (broadcast_id) REFERENCES public.broadcasts(id);


--
-- Name: broadcast_messages broadcast_messages_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_messages
    ADD CONSTRAINT broadcast_messages_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: broadcast_progress broadcast_progress_broadcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_progress
    ADD CONSTRAINT broadcast_progress_broadcast_id_fkey FOREIGN KEY (broadcast_id) REFERENCES public.broadcasts(id);


--
-- Name: broadcast_recipients broadcast_recipients_broadcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_broadcast_id_fkey FOREIGN KEY (broadcast_id) REFERENCES public.broadcasts(id) ON DELETE CASCADE;


--
-- Name: broadcast_recipients broadcast_recipients_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_recipients
    ADD CONSTRAINT broadcast_recipients_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE CASCADE;


--
-- Name: broadcast_templates broadcast_templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcast_templates
    ADD CONSTRAINT broadcast_templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: broadcasts broadcasts_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcasts
    ADD CONSTRAINT broadcasts_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.broadcast_templates(id);


--
-- Name: broadcasts broadcasts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.broadcasts
    ADD CONSTRAINT broadcasts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: contact_categories contact_categories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_categories
    ADD CONSTRAINT contact_categories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: contact_category_relations contact_category_relations_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_category_relations
    ADD CONSTRAINT contact_category_relations_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.contact_categories(id) ON DELETE CASCADE;


--
-- Name: contact_category_relations contact_category_relations_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contact_category_relations
    ADD CONSTRAINT contact_category_relations_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE CASCADE;


--
-- Name: contacts contacts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: incoming_messages incoming_messages_phone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.incoming_messages
    ADD CONSTRAINT incoming_messages_phone_id_fkey FOREIGN KEY (phone_id) REFERENCES public.phone_numbers(id);


--
-- Name: message_templates message_templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_phone_number_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_phone_number_id_fkey FOREIGN KEY (phone_number_id) REFERENCES public.phone_numbers(id) ON DELETE CASCADE;


--
-- Name: phone_numbers phone_numbers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.phone_numbers
    ADD CONSTRAINT phone_numbers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: rate_limits rate_limits_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: webhook_events webhook_events_phone_number_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chatflow_user
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_phone_number_id_fkey FOREIGN KEY (phone_number_id) REFERENCES public.phone_numbers(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict XchIg4hLueG6udYxU91sXPPqYGySFHwtSUUxVneXyKoH9CpdrLbA3NhCoamTddW

